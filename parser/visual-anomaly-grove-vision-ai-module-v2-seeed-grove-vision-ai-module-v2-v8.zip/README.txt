Seeed Grove Vision AI Module V2 (Himax WiseEye2)
------------------------------------------------

For flashing instructions and details on how to use this firmware, see the tutorial:
https://docs.edgeimpulse.com/docs/development-platforms/officially-supported-mcu-targets/seeed-grove-vision-ai-module-v2

(c) Copyright 2024 Edge Impulse Inc., all rights reserved.
